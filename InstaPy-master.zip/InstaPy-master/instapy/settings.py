class Settings:
    database_location = "./db/instapy.db"
    browser_location = "./assets/chromedriver"
